(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
    'userProfile': function (githubInfo) {                             // 2
        var info = {                                                   // 3
            avatar: githubInfo.avatar_url,                             // 4
            followers: githubInfo.followers,                           // 5
            following: githubInfo.following,                           // 6
            repos: githubInfo.public_repos                             // 7
        };                                                             //
        Meteor.users.update(this.userId, { $set: info });              // 9
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=methods.js.map
