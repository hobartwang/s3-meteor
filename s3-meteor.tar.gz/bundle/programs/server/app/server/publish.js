(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publish.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish("userData", function () {                               // 1
  return Meteor.users.find({ _id: this.userId }, { fields: { avatar: 1, followers: 1, repos: 1, following: 1 } });
});                                                                    //
                                                                       //
Meteor.publish("messages", function () {                               // 8
  return Messages.find();                                              // 9
});                                                                    //
                                                                       //
Meteor.publish("userStatus", function () {                             // 12
  return Meteor.users.find({ "status.online": true });                 // 13
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publish.js.map
